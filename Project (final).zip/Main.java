/**
 * Main method runs the program
 *
 * @version 1.0 12/7/20
 * @author Dennis Lang
 */

public class Main {
  public static void main(String[] args) {
    Attendance.main(args);
  }
}